package ni.edu.uam.techstock_api.repository;

import ni.edu.uam.techstock_api.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
}