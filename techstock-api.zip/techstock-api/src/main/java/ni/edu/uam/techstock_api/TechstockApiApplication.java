package ni.edu.uam.techstock_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechstockApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechstockApiApplication.class, args);
	}

}
