package ni.edu.uam.techstock_api.repository;

import ni.edu.uam.techstock_api.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, Long> {
}