package ni.edu.uam.techstock_api.service;

import ni.edu.uam.techstock_api.model.Producto;
import ni.edu.uam.techstock_api.repository.ProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class ProductoService {
    @Autowired
    private ProductoRepository repository;

    public List<Producto> findAll() { return repository.findAll(); }
    public Optional<Producto> findById(Long id) { return repository.findById(id); }
    public Producto save(Producto producto) { return repository.save(producto); }
    public void deleteById(Long id) { repository.deleteById(id); }
}