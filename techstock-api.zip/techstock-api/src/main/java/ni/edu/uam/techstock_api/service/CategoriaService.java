package ni.edu.uam.techstock_api.service;

import ni.edu.uam.techstock_api.model.Categoria;
import ni.edu.uam.techstock_api.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {
    @Autowired
    private CategoriaRepository repository;

    public List<Categoria> findAll() { return repository.findAll(); }
    public Optional<Categoria> findById(Long id) { return repository.findById(id); }
    public Categoria save(Categoria categoria) { return repository.save(categoria); }
    public void deleteById(Long id) { repository.deleteById(id); }
}