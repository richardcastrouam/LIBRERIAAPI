package ni.edu.uam.techstock_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechstockApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
