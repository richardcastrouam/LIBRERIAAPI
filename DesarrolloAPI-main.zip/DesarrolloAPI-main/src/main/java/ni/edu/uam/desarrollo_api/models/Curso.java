package ni.edu.uam.desarrollo_api.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/**
 * Entidad que representa la tabla cursos en la base de datos.
 *
 * Esta clase almacena la información de los cursos disponibles
 * dentro del sistema académico.
 *
 * Se utiliza JPA para mapear la clase con la tabla y Lombok
 * para generar automáticamente getters, setters y constructores.
 */

@Entity
@Table(name="cursos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Curso {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="id_curso")
    private Long id;

    @Column(name="nombre_curso", nullable=false, unique=true, length=120)
    private String nombre;

    @Column(name="precio_curso", nullable=false, precision=10, scale=2)
    private BigDecimal precio;
}
