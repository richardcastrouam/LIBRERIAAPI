package ni.edu.uam.desarrollo_api.repository;

import ni.edu.uam.desarrollo_api.models.Estudiante;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio de acceso a datos para la entidad Estudiante.
 *
 * Esta interfaz permite realizar operaciones CRUD sobre la tabla
 * estudiantes utilizando Spring Data JPA.
 *
 * Tipo de entidad gestionada: Estudiante
 * Tipo de clave primaria: Long
 *
 * Métodos disponibles heredados:
 * - save()
 * - findAll()
 * - findById()
 * - deleteById()
 * - existsById()
 * - count()
 *
 * También se pueden agregar consultas personalizadas en el futuro,
 * por ejemplo:
 *
 * List<Estudiante> findByApellidos(String apellidos);
 * Optional<Estudiante> findByCorreo(String correo);
 */

public interface EstudianteRepo extends JpaRepository<Estudiante,Long> {
}
