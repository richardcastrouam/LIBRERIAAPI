package ni.edu.uam.desarrollo_api.services;

import ni.edu.uam.desarrollo_api.models.Estudiante;
import ni.edu.uam.desarrollo_api.repository.EstudianteRepo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio encargado de la lógica de negocio relacionada
 * con la entidad Estudiante.
 *
 * Permite administrar los registros de estudiantes y funciona
 * como capa intermedia entre el controlador y el repositorio.
 */

@Service
public class EstudianteService {
    private final EstudianteRepo estudianteRepo;

    public EstudianteService(EstudianteRepo estudianteRepo) {
        this.estudianteRepo = estudianteRepo;
    }

    public List<Estudiante> getAllEstudiantes() {
        return estudianteRepo.findAll();
    }

    public Estudiante getEstudianteById(Long id) {
        return estudianteRepo.findById(id).orElse(null);
    }

    public Estudiante saveEstudiante (Estudiante estudiante) {
        return estudianteRepo.save(estudiante);
    }

    public void deleteEstudiante(Long id) {
        estudianteRepo.deleteById(id);
    }
}
