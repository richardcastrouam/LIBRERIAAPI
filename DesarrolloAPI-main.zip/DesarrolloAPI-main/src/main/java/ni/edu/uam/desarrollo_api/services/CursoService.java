package ni.edu.uam.desarrollo_api.services;

import ni.edu.uam.desarrollo_api.models.Curso;
import ni.edu.uam.desarrollo_api.repository.CursoRepo;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Servicio encargado de la lógica de negocio relacionada
 * con la entidad Curso.
 *
 * Actúa como intermediario entre el controlador y el repositorio,
 * permitiendo gestionar las operaciones CRUD de los cursos.
 */

@Service
public class CursoService {
    private final CursoRepo cursoRepo;

    public CursoService(CursoRepo cursoRepo) {
        this.cursoRepo = cursoRepo;
    }

    public List<Curso> getAllCursos() {
        return cursoRepo.findAll();
    }

    public Curso getCursoById(Long id) {
        return cursoRepo.findById(id).orElse(null);
    }

    public Curso saveCurso (Curso curso) {
        return cursoRepo.save(curso);
    }

    public void deleteCurso(Long id) {
        cursoRepo.deleteById(id);
    }
}
