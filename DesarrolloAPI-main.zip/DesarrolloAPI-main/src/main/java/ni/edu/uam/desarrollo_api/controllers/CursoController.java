package ni.edu.uam.desarrollo_api.controllers;

import ni.edu.uam.desarrollo_api.models.Curso;
import ni.edu.uam.desarrollo_api.services.CursoService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la gestión de cursos.
 *
 * Expone los endpoints HTTP necesarios para realizar
 * operaciones CRUD sobre la entidad Curso.
 *
 * URL base:
 * /api/cursos
 */

@RestController
@RequestMapping("/api/cursos")
public class CursoController {
    private final CursoService cursoService;

    public CursoController(CursoService cursoService) {
        this.cursoService = cursoService;
    }

    @GetMapping
    public List<Curso> getAllCursos() {
        return cursoService.getAllCursos();
    }

    @GetMapping("/{id}")
    public Curso getCursoById(@PathVariable Long id) {
        return cursoService.getCursoById(id);
    }

    @PostMapping
    public Curso saveCurso(@RequestBody Curso curso) {
        return cursoService.saveCurso(curso);
    }

    @PutMapping("/{id}")
    public Curso updateCurso(@PathVariable Long id, @RequestBody Curso curso) {
        curso.setId(id);
        return cursoService.saveCurso(curso);
    }

    @DeleteMapping("/{id}")
    public void deleteCurso(@PathVariable Long id){
        cursoService.deleteCurso(id);
    }
}
