package ni.edu.uam.desarrollo_api.repository;

import ni.edu.uam.desarrollo_api.models.Curso;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repositorio de acceso a datos para la entidad Curso.
 *
 * Esta interfaz extiende JpaRepository, lo que permite utilizar
 * métodos predefinidos para operaciones CRUD sin necesidad de
 * escribir consultas manuales.
 *
 * Tipo de entidad gestionada: Curso
 * Tipo de clave primaria: Long
 *
 * Funcionalidades heredadas:
 * - save()
 * - findAll()
 * - findById()
 * - deleteById()
 * - existsById()
 * - count()
 *
 * Spring Data JPA implementa automáticamente esta interfaz
 * en tiempo de ejecución.
 */

public interface CursoRepo extends JpaRepository<Curso,Long> {
}
