package ni.edu.uam.desarrollo_api.controllers;

import ni.edu.uam.desarrollo_api.models.Estudiante;
import ni.edu.uam.desarrollo_api.services.EstudianteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la gestión de estudiantes.
 *
 * Permite realizar operaciones CRUD sobre la entidad Estudiante
 * mediante solicitudes HTTP.
 *
 * URL base:
 * /api/estudiantes
 */

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {
    private final EstudianteService estudianteService;

    public EstudianteController(EstudianteService estudianteService) {
        this.estudianteService = estudianteService;
    }

    @GetMapping
    public List<Estudiante> getAllEstudiantes() {
        return estudianteService.getAllEstudiantes();
    }

    @GetMapping("/{id}")
    public Estudiante getEstudianteById(@PathVariable Long id) {
        return estudianteService.getEstudianteById(id);
    }


    @PostMapping
    public Estudiante saveEstudiante(@RequestBody Estudiante estudiante) {
        return estudianteService.saveEstudiante(estudiante);
    }

    @PutMapping("/{id}")
    public Estudiante updateEstudiante(@PathVariable Long id, @RequestBody Estudiante estudiante) {
        estudiante.setId(id);
        return estudianteService.saveEstudiante(estudiante);
    }

    @DeleteMapping("/{id}")
    public void deleteEstudentiante(@PathVariable Long id){
        estudianteService.deleteEstudiante(id);
    }
}
