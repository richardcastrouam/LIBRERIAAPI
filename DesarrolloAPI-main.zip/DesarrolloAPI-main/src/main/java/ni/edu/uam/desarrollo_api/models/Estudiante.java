package ni.edu.uam.desarrollo_api.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * Entidad que representa la tabla estudiantes en la base de datos.
 *
 * Contiene la información personal y académica de cada estudiante,
 * incluyendo la relación con el curso al que pertenece.
 *
 * La relación establecida es Muchos a Uno:
 * varios estudiantes pueden estar inscritos en un mismo curso.
 */

@Entity
@Table(name="estudiantes")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Estudiante {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "id_estudiante")
    private Long id;

    @Column(name="nombres_estudiante",nullable=false, length = 60)
    private String nombres;

    @Column(name="apellidos_estudiante",nullable=false, length = 60)
    private String apellidos;

    @Column(name="email",nullable=false, unique = true, length = 150)
    private String correo;

    @Column(name="fecha_nacimiento")
    private LocalDate fechaNacimiento;

    @Column(name="telefono", length=15)
    private String telefono;

    @Column(name="tipo_sangre",length=3)
    private String tipoSangre;

    @Column(name="sexo")
    private boolean sexo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="id_curso",nullable=false)
    private Curso curso;
}
